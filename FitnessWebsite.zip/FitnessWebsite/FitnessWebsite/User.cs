﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FitnessWebsite
{
    public class User
    {
        // private property fields
        // these hold data that describes the User object
        private string firstName;
        private string lastName;
        private int age;
        private double weightPounds;
        private int heightInches;
        private Dictionary<string, double> measurements;
        private string colorPref;
        private string gender;
        private int restingMetabolicRate;
        private double bodyFatPercentage;
        private double activityLevel;
        private string username;

        // default Constructor
        public User()
        {

        }

        // constructor using gender
        public User(string gender)
        {
            if (gender.Equals("male"))
            {
                measurements.Add("waist", 0);
            }
            else
            {
                measurements.Add("waist", 0);
                measurements.Add("wrist", 0);
                measurements.Add("hip", 0);
                measurements.Add("forearm", 0);
            }
        }

        // methods - behaviors
        // these are the actions that the User object can perform
        public void calculateRMR()
        {
            if (this.gender.Equals("male"))
            {
                this.restingMetabolicRate = Convert.ToInt32((10 * (this.weightPounds / 2.2046)) + (6.25 * (this.heightInches * 2.54))
                     - (5 * this.age) + 5);
            }
            else if (this.gender.Equals("female"))
            {
                this.restingMetabolicRate = Convert.ToInt32((10 * (this.weightPounds / 2.2046)) + (6.25 * (this.heightInches * 2.54))
                     - (5 * this.age) - 161);
            }
        }

        public void calculateBFP()
        {
            if (this.gender.Equals("male"))
            {
                double result1 = (this.weightPounds * 1.082) + 94.42;
                double result2 = this.measurements["waist"] * 4.15;
                double lbm = result1 - result2;
                this.bodyFatPercentage = ((this.weightPounds - lbm) * 100) / this.weightPounds;

            }
            else if (this.gender.Equals("female"))
            {
                double result2 = (this.weightPounds * .732) + 8.987;
                double result3 = this.measurements["wrist"] / 3.14;
                double result4 = this.measurements["waist"] * .157;
                double result5 = this.measurements["hip"] * .249;
                double result6 = this.measurements["forearm"] * .434;
                double result7 = result2 + result3;
                double result8 = result7 - result4;
                double result9 = result8 - result5;
                double lbm = result9 + result6;
                this.bodyFatPercentage = ((this.weightPounds - lbm) * 100) / this.weightPounds;
            }
        }

        // Property Accessor methods (getters and setters)
        // these provide access to the private data fields
        public string Username
        {
            get
            {
                return username;
            }
            set
            {
                username = value;
            }
        }

        public double ActivityLevel
        {
            get
            {
                return activityLevel;
            }
            set
            {
                activityLevel = value;
            }
        }

        public double BFP
        {
            get
            {
                return bodyFatPercentage;
            }
            set
            {
                bodyFatPercentage = value;
            }
        }

        public int RMR
        {
            get
            {
                return restingMetabolicRate;
            }
            set
            {
                restingMetabolicRate = value;
            }
        }

        public string Gender
        {
            get
            {
                return gender;
            }
            set
            {
                gender = value;
            }
        }

        public string ColorPref
        {
            get
            {
                return colorPref;
            }
            set
            {
                colorPref = value;
            }
        }

        public Dictionary<string, double> Measurements
        {
            get
            {
                return measurements;
            }
            set
            {
                measurements = value;
            }
        }

        public int HeightInches
        {
            get
            {
                return heightInches;
            }
            set
            {
                heightInches = value;
            }
        }

        public double WeightPounds
        {
            get
            {
                return weightPounds;
            }
            set
            {
                weightPounds = value;
            }
        }

        public int Age
        {
            get
            {
                return age;
            }
            set
            {
                age = value;
            }
        }

        public string LastName
        {
            get
            {
                return lastName;
            }
            set
            {
                lastName = value;
            }
        }

        public string FirstName
        {
            get
            {
                return firstName;
            }
            set
            {
                firstName = value;
            }
        }
    }
}