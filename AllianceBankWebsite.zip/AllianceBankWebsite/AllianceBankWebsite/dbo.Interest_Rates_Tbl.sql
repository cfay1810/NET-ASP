﻿CREATE TABLE [dbo].[Interest_Rates_Tbl]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Rate_Type] NCHAR(10) NULL, 
    [Product_Desc] NCHAR(10) NULL, 
    [Interest_Rate] DECIMAL NULL
)
